# Respostas — Experiência prática I

## 1. Principais tags semânticas utilizadas

Cada linha corresponde a uma entrada no formulário. Informe o nome da tag sem os sinais `<` e `>`.


| Nome da tag | Propósito ou conteúdo abrigado                                                                    |
| ----------- | ------------------------------------------------------------------------------------------------- |
| `header`    | Apresenta o nome da ONG e reúne o menu de navegação no topo das páginas.                          |
| `nav`       | Organiza os links de navegação entre as páginas Início, Projetos sociais e Participe.             |
| `main`      | Abriga o conteúdo principal de cada página, como a apresentação da ONG e os projetos sociais.     |
| `section`   | Agrupa conteúdos do mesmo assunto, como Quem somos, Nossas iniciativas e Voluntariado.            |
| `article`   | Apresenta cada projeto social de forma independente, com descrição, objetivo e atividades.        |
| `aside`     | Apresenta uma observação complementar sobre o caráter acadêmico e fictício do site.               |
| `footer`    | Exibe informações de encerramento, identificando a ONG e o caráter fictício do projeto acadêmico. |
| `address`   | Reúne o e-mail e o endereço de contato da ONG, identificados como fictícios.                      |
| `img`       | Apresenta uma ilustração de um livro aberto com texto alternativo no atributo alt.                |
| `h1`        | Identifica o tema principal de cada página.                                                       |
| `h2`        | Identifica as seções principais e os títulos dos projetos sociais.                                |
| `h3`        | Identifica subdivisões, como missão, valores, objetivos e atividades.                             |


## 2. Justificativa da hierarquia de títulos e sua contribuição para a acessibilidade

```text
Utilizei um título h1 por página para identificar seu tema principal. Os títulos h2 organizam os assuntos principais, como “Quem somos” e os projetos sociais. Os títulos h3 identificam subdivisões, como “Nossa missão”, “Objetivo” e “Atividades”. Não foi necessário utilizar h4, h5 e h6, pois o conteúdo não apresenta subdivisões mais profundas. Os níveis foram escolhidos conforme a organização dos assuntos, sem saltos na hierarquia. Essa estrutura facilita a leitura e a compreensão do conteúdo. Também favorece a acessibilidade, permitindo que usuários de leitores de tela naveguem pelos títulos e compreendam a relação entre as seções da página.
```

## 3. A tag h1 é semântica?

Sim. A tag `<h1>` tem significado semântico: identifica um título de nível 1.
Neste projeto, ela representa o tema principal de cada página.
As tags `<h2>` a `<h6>` também possuem significado semântico e representam
os demais níveis de títulos. Elas podem ser incluídas na lista de tags
utilizadas, mas só devemos listar os níveis presentes no desenvolvimento:
`<h1>`, `<h2>` e `<h3>`.

## 4. Trecho principal do index.html: apresentação institucional e contato

Copie apenas o conteúdo do bloco para o campo de código HTML. Os dados de contato são fictícios e estão identificados dessa forma na página.

```html
  <main id="conteudo">
    <h1>Juntos por uma comunidade mais acolhedora</h1>
    <p>A Laços da Comunidade é uma ONG fictícia dedicada à educação, à convivência e ao apoio a famílias.</p>

    <picture>
      <source srcset="../imagens/leitura-comunitaria.svg" type="image/svg+xml">
      <source srcset="../imagens/leitura-comunitaria.webp" type="image/webp">
    <img src="../imagens/leitura-comunitaria.png"
         alt="Livro aberto, símbolo das iniciativas de educação e leitura da ONG."
         width="800" height="400" style="max-width: 100%; height: auto;">
    </picture>

    <!-- Cada section reúne um assunto e recebe um título descritivo. -->
    <section aria-labelledby="sobre">
      <h2 id="sobre">Quem somos</h2>
      <p>Reunimos pessoas que desejam compartilhar conhecimentos e construir oportunidades na comunidade.</p>
      <h3>Nossa missão</h3>
      <p>Promover o acesso à educação e fortalecer os vínculos entre os moradores.</p>
      <h3>Nossos valores</h3>
      <ul>
        <li>Respeito à diversidade.</li>
        <li>Solidariedade nas ações cotidianas.</li>
        <li>Transparência e responsabilidade.</li>
      </ul>
    </section>

    <section aria-labelledby="iniciativas">
      <h2 id="iniciativas">Nossas iniciativas</h2>
      <p>Os projetos oferecem apoio aos estudos e oportunidades de leitura para crianças, jovens e adultos.</p>
      <a href="projetos.html">Conheça os projetos sociais</a>
    </section>
    <section aria-labelledby="contato">
      <h2 id="contato">Entre em contato</h2>
      <p>Dados fictícios para fins acadêmicos; não são canais reais de atendimento.</p>
      <!-- address identifica as informações de contato da organização. -->
      <address>
        <p>Laços da Comunidade</p>
        <p>E-mail: <a href="mailto:contato@lacos.example">contato@lacos.example</a></p>
        <p>Endereço: Rua Exemplo, 100 — Bairro Comunidade, Cidade Exemplo.</p>
      </address>
    </section>
  </main>
```

## 5. Integração da imagem e acessibilidade pelo atributo alt

```text
Integrei a ilustração local de um livro aberto usando picture, com versões SVG e WebP em elementos source e PNG como alternativa na tag img. O navegador escolhe um formato compatível. O atributo alt da img contém “Livro aberto, símbolo das iniciativas de educação e leitura da ONG.”, comunicando o significado da imagem aos usuários de leitores de tela. O texto alternativo vale para qualquer formato escolhido. Os atributos width e height definem as dimensões, enquanto max-width: 100% e height: auto ajustam a imagem ao espaço disponível sem distorção. As versões PNG e WebP foram otimizadas sem perda de qualidade.
```

## 6. Blocos informativos do arquivo projetos.html e suas estruturas HTML

Adicione uma entrada por linha no formulário.


| Bloco de informação        | Estrutura HTML utilizada                                                                                                           |
| -------------------------- | ---------------------------------------------------------------------------------------------------------------------------------- |
| Apresentação da página     | main abriga o conteúdo principal, com h1 para o título e p para a introdução.                                                      |
| Navegação pelos assuntos   | nav com ul, li e links a para acessar os projetos, o voluntariado e as doações.                                                    |
| Projeto Aprender juntos    | article com h2 para o nome, h3 para objetivo e atividades, p para descrições e ul para a lista de atividades.                      |
| Projeto Leitura para todos | article com h2 para o nome, h3 para objetivo e atividades, p para descrições e ul para a lista de atividades.                      |
| Trabalho voluntário        | section com h2, subtítulos h3, lista ul de atuações, lista ol de passos e link a para a página de participação.                    |
| Campanhas de doação        | section com h2, subtítulos h3 para materiais, contribuição financeira e transparência, parágrafos p, lista ol e link a de contato. |


## 7. Como a organização orienta quem deseja contribuir ou atuar como voluntário

```text
Organizei a página para apresentar primeiro os projetos, seus objetivos e suas atividades. Em seguida, separei as orientações de trabalho voluntário e as campanhas de doação em seções com títulos claros. O menu interno permite acessar diretamente cada assunto. As listas de atividades ajudam o visitante a identificar como pode colaborar, enquanto as listas numeradas apresentam os passos para participar ou buscar orientações sobre contribuições financeiras. A seção de doações explica a destinação dos recursos e o modelo proposto de prestação de contas. Os links conduzem à página de participação e à seção de contato. A hierarquia de títulos h1, h2 e h3 facilita a leitura e a navegação por leitores de tela. Como se trata de um projeto acadêmico, a página informa que os contatos são fictícios e que não há doações ou inscrições reais.
```

## 8. Etapa de cadastro — implementação realizada

```text
Criei cadastro.html com agrupamentos fieldset e legend para dados pessoais, endereço e interesse em participar. Associei os rótulos aos campos e utilizei os tipos text, email, date e tel, além de select e checkbox. Apliquei required, minlength, maxlength e pattern conforme a finalidade dos campos. O JavaScript formata CPF, telefone e CEP, verifica os dígitos verificadores do CPF e limita a data de nascimento ao dia atual. A validação nativa permanece habilitada: ao tentar concluir, o navegador apresenta automaticamente os erros de required, type, pattern e limites. Mensagens complementares são associadas aos campos por aria-describedby, com aria-invalid. O primeiro campo inválido recebe foco ao concluir. O formulário também verifica nome e sobrenome, formato de e-mail e número do endereço, informa o resultado em uma região de status e não envia nem armazena dados. O HTML foi verificado no Nu HTML Checker do W3C, sem erros ou avisos no resultado final.
```

## 9. Agrupamento lógico dos campos em cadastro.html

```text
Organizei o formulário dentro de um fieldset principal com a legend “Cadastro demonstrativo”. Esse agrupamento permanece desabilitado até o carregamento do JavaScript, evitando envio acidental sem as funções da demonstração. Dentro dele, criei três fieldsets, cada um identificado por uma legend. “Dados pessoais” reúne nome completo, e-mail, data de nascimento, CPF e telefone. “Endereço” reúne CEP, logradouro, número, complemento, bairro, cidade e estado. “Interesse em participar” contém a seleção da forma de participação e a confirmação de uso de dados fictícios. Essa divisão aproxima campos relacionados e torna o preenchimento mais fácil de compreender. As legends identificam semanticamente os grupos, oferecendo contexto também aos usuários de leitores de tela. Cada campo possui um label associado: nos campos individuais, por for e id; na confirmação, o checkbox está dentro do label. As instruções de formato e as mensagens de erro são associadas aos campos por aria-describedby. O complemento é opcional, e os demais campos são obrigatórios.
```

## 10. Campos do formulário: atributo type e justificativa

Adicione uma entrada por linha. A primeira coluna corresponde a “Nome do campo” e a segunda a “Atributo type e justificativa”. Os textos respeitam os limites de 50 e 150 caracteres.


| Nome do campo                         | Atributo type e justificativa                                                                                                   |
| ------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------- |
| Nome completo                         | type="text": recebe nome e sobrenome, com espaços e letras; o JavaScript verifica o preenchimento.                              |
| E-mail                                | type="email": permite verificar o formato de e-mail e oferece teclado adequado em dispositivos móveis.                          |
| Data de nascimento                    | type="date": permite escolher uma data; o atributo max impede datas futuras.                                                    |
| CPF                                   | type="text": preserva zeros iniciais e aceita a máscara. inputmode="numeric" sugere teclado numérico; o JS verifica os dígitos. |
| Telefone com DDD                      | type="tel": representa um telefone, aceita pontuação e favorece o teclado telefônico. pattern e JavaScript validam o formato.   |
| CEP                                   | type="text": preserva zeros iniciais e o hífen da máscara. inputmode="numeric" facilita a digitação dos oito dígitos.           |
| Logradouro                            | type="text": aceita nomes de ruas e avenidas, incluindo letras, números e espaços.                                              |
| Número (ou s/n)                       | type="text": aceita número, sufixo de letra ou s/n, formatos que type="number" não comporta.                                    |
| Complemento                           | type="text": permite informações livres, como apartamento ou bloco. O preenchimento é opcional.                                 |
| Bairro                                | type="text": aceita o nome do bairro, com letras e espaços.                                                                     |
| Cidade                                | type="text": aceita o nome da cidade, incluindo espaços e acentos.                                                              |
| Estado (UF)                           | Utilizei select, sem atributo type, com as 27 UFs como opções para padronizar a escolha e evitar erros de digitação.            |
| Forma de participação                 | Utilizei select, sem atributo type, para escolher trabalho voluntário, campanhas de doação ou ambas as opções.                  |
| Confirmação de uso de dados fictícios | type="checkbox": registra uma confirmação explícita; required exige sua marcação antes de concluir a demonstração.              |


## 11. Dados validados e atributos nativos utilizados

Adicione uma entrada por linha. As três primeiras correspondem aos campos destacados no enunciado.


| Dado validado                         | Atributos HTML e padrão adotado                                                                                                |
| ------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------ |
| CPF                                   | pattern="\[0-9\]{3}.\[0-9\]{3}.\[0-9\]{3}-\[0-9\]{2}" e required: exigem o formato 000.000.000-00 e o preenchimento.           |
| Telefone                              | pattern="(\[0-9\]{2}) \[0-9\]{4,5}-\[0-9\]{4}" e required: exigem DDD e telefone no formato (00) 0000-0000 ou (00) 00000-0000. |
| CEP                                   | pattern="\[0-9\]{5}-\[0-9\]{3}" e required: exigem oito dígitos no formato 00000-000 e o preenchimento.                        |
| Nome completo                         | required, minlength="3" e maxlength="100": exigem preenchimento e limitam o tamanho do nome.                                   |
| E-mail                                | type="email", required e maxlength="150": verificam o formato de e-mail, exigem preenchimento e limitam o tamanho.             |
| Data de nascimento                    | type="date", required e max atualizado pelo JavaScript para a data atual: exigem uma data e impedem datas futuras.             |
| Logradouro, número, bairro e cidade   | required: exige o preenchimento de cada campo. O complemento é opcional.                                                       |
| Estado e forma de participação        | required nos elementos select: exige escolher uma opção com valor, em vez de manter “Selecione”.                               |
| Confirmação de uso de dados fictícios | type="checkbox" e required: exigem marcar a confirmação antes de concluir.                                                     |


Os padrões estão transcritos do HTML. inputmode sugere o teclado, mas não valida o conteúdo. A formatação durante a digitação e a verificação dos dígitos do CPF são feitas pelo JavaScript.

## 12. Contribuição das validações para a integridade dos dados

```text
O atributo pattern verifica se o valor completo corresponde ao formato esperado para CPF, telefone e CEP. Ele não insere pontuação: essa máscara é aplicada pelo JavaScript. O atributo required exige o preenchimento dos campos obrigatórios e a marcação da confirmação. Os atributos minlength e maxlength limitam o tamanho dos textos, type="email" verifica o formato do e-mail e type="date", combinado com max, restringe a data de nascimento. No projeto, o JavaScript consulta a validade nativa dos campos e acrescenta regras, como a conferência dos dígitos verificadores do CPF. O formulário mantém a validação interativa nativa habilitada, sem novalidate e sem formnovalidate. Ao tentar concluir com campos vazios ou formatos inválidos, o próprio navegador bloqueia a submissão, focaliza o primeiro campo inválido e apresenta sua mensagem automaticamente. As mensagens junto aos campos são complementares e não substituem essa experiência nativa. Isso reduz omissões e inconsistências, mas não comprova a existência dos dados informados. Em uma aplicação real, o servidor também deve validar os dados, pois as verificações no navegador podem ser contornadas. Neste exercício, nenhum dado é enviado ou armazenado.
```

## 13. Imagens para anexar individualmente

O formulário “Adicionar imagem” pede um título e um arquivo de imagem por envio. Não selecione os arquivos ZIP nesse campo.


| Título              | Arquivo a selecionar na pasta imagens |
| ------------------- | ------------------------------------- |
| Livro aberto — PNG  | leitura-comunitaria.png               |
| Livro aberto — WebP | leitura-comunitaria.webp              |
| Livro aberto — SVG  | leitura-comunitaria.svg               |


Clique em “Selecionar arquivo”, escolha o arquivo e clique no ícone de salvar. Repita para cada formato aceito pela plataforma. Comece pelo PNG; se o seletor recusar WebP ou SVG, não altere apenas a extensão dos arquivos. As três versões representam a mesma ilustração e são utilizadas pelo elemento picture na página inicial. Todos os arquivos estão abaixo do limite de 50 MB.

Os pacotes da pasta entrega permanecem disponíveis para entrega do projeto por outro canal. Este campo de imagens não serve para anexar o código-fonte.

## 14. Estrutura de diretórios

Adicione uma pasta por vez. Copie a primeira coluna para “Nome da pasta ou diretório raiz” e a segunda para “Arquivos contidos”. Todas as entradas respeitam os limites de 60 e 500 caracteres.


| Nome da pasta ou diretório raiz | Arquivos contidos                                                                                                          |
| ------------------------------- | -------------------------------------------------------------------------------------------------------------------------- |
| Experiencia-Pratica-1           | README.md e respostas.md. Contém as subpastas html, imagens, js, validacao e entrega.                                      |
| html                            | index.html, projetos.html, participe.html e cadastro.html.                                                                 |
| imagens                         | leitura-comunitaria.svg, leitura-comunitaria.webp, leitura-comunitaria.png e .gitkeep (arquivo auxiliar do versionamento). |
| js                              | cadastro.js.                                                                                                               |
| validacao                       | index-w3c.json, projetos-w3c.json, participe-w3c.json e cadastro-w3c.json.                                                 |
| entrega                         | imagens-otimizadas.zip, projeto-completo.zip e codigo-fonte-completo.txt.                                                  |


## 15. Código-fonte completo — link do GitHub

Atenção: na conferência, o projeto estava no commit local e022fb9, ainda não publicado na branch main do GitHub. Publique esse commit antes de entregar o link abaixo. Depois, confira se a pasta abre para o avaliador; se o repositório for privado, ele precisará de acesso.

Copie o texto abaixo para o campo de código-fonte somente após publicar e conferir o acesso:

```text
O código-fonte completo está disponível no GitHub: https://github.com/rita-moura/desenvolvimento-front-end-para-web/tree/main/Experiencia-Pratica-1

A pasta html contém index.html, projetos.html, participe.html e cadastro.html. A pasta js contém as máscaras e validações do formulário; imagens reúne os recursos visuais; validacao contém os relatórios do W3C. Para executar o projeto, baixe o repositório e abra Experiencia-Pratica-1/html/index.html no navegador. Não é necessário instalar dependências.
```

## 16. Resultado da validação W3C e correções efetuadas

```text
Submeti os arquivos index.html, projetos.html, participe.html e cadastro.html ao Nu HTML Checker do W3C. Na primeira validação do cadastro, a ferramenta apontou um erro no valor tel-national do atributo autocomplete do campo de telefone. Substituí esse valor por tel e submeti novamente o arquivo. Após a correção e a inclusão das versões de imagem no elemento picture, repeti a validação das quatro páginas. Os resultados finais não apresentaram erros nem avisos, retornando a lista messages vazia. Os relatórios foram salvos na pasta validacao, em arquivos JSON individuais para cada página. Além da conferência da marcação HTML, os testes automatizados no navegador verificaram campos obrigatórios vazios, formatos inválidos, máscaras e conclusão com dados de exemplo. Após remover a desativação da validação interativa, os 18 testes passaram em desktop e celular, incluindo as mensagens nativas e o bloqueio da submissão pelas restrições HTML. A validação do W3C verifica a conformidade do HTML; ela não substitui os testes de funcionamento do JavaScript nem uma avaliação completa de acessibilidade.
```

## 17. Reflexão sobre a aprendizagem

Sugestão baseada nas atividades realizadas. Revise para que o texto represente sua percepção pessoal sobre a aprendizagem.

```text
Nesta experiência prática, avancei na compreensão de que desenvolver uma página web envolve mais do que apresentar textos e imagens. A escolha das tags semânticas, a hierarquia dos títulos e a organização dos arquivos ajudam a tornar o conteúdo compreensível, acessível e mais fácil de manter. Entre meus pontos fortes, destaco a atenção aos requisitos e a disposição para revisar o resultado. Ao experimentar o formulário, percebi que as validações precisavam ficar mais claras para quem preenche os campos, o que levou à revisão das máscaras e à inclusão de mensagens de erro. Também compreendi melhor a diferença entre formatar um dado e verificar sua validade: a máscara organiza a digitação, mas não garante que a informação esteja correta ou exista. Como oportunidades de melhoria, reconheço a necessidade de praticar mais JavaScript e expressões regulares para compreender e implementar essas regras com maior autonomia. Preciso também ampliar os testes de acessibilidade e de navegação por teclado, além de planejar a entrega com antecedência, considerando os formatos aceitos pela plataforma e a publicação do código no GitHub. A validação pelo W3C mostrou a importância de conferir a marcação e corrigir os problemas encontrados, sem substituir os testes de funcionamento. Esses aprendizados contribuem para meu desenvolvimento profissional ao incentivar uma postura de organização, revisão e atenção à experiência do usuário. Ainda estou consolidando esses conhecimentos, mas a atividade me ajudou a relacionar a teoria do HTML5 com decisões práticas de desenvolvimento.
```

#   
  
# Respostas — Experiência prática II


---

## Etapa 2 — Design system e estruturação responsiva

Esta seção reúne as respostas da nova etapa, dedicada à evolução visual do mesmo projeto da ONG. As respostas anteriores correspondem à etapa de HTML5.

### Objetivos apresentados no enunciado

- Criar um sistema de design com variáveis customizadas em CSS.
- Definir regras globais de cores, tipografia escalável e espaçamentos modulares.
- Implementar o layout principal com CSS Grid de 12 colunas e breakpoints definidos.
- Usar Flexbox para alinhamentos e componentes internos da interface.

As próximas respostas serão identificadas pelo prefixo **CSS**, seguido do número e do assunto da pergunta. Elas serão registradas conforme os requisitos forem implementados e verificados.

### CSS 1 — Variáveis do Design System: cores, tipografia e espaçamentos

```text
Organizei o Design System no seletor :root de estilos.css, compartilhado pelas quatro páginas. As propriedades customizadas são utilizadas com var(), centralizando as decisões visuais e facilitando a manutenção. CORES: --verde: #205c4a é a cor primária de links, botões e navegação ativa; --escuro: #193b32 atende aos textos e ao hover; --secundaria: #e8f0e9 compõe superfícies de apoio; --ilustracao: #e8f2ef identifica o fundo da imagem. Os neutros são --fundo: #f4f6f0, --superficie: #ffffff, --borda: #d4dfd6, --borda-campo: #718779 e --texto-suave: #486358. Completam a paleta --erro: #a31515 e --foco: #956100. São 11 cores distintas, com funções definidas. TIPOGRAFIA: --fonte-familia usa system-ui, sans-serif. Os cinco níveis são --fonte-1: 0.875rem para textos auxiliares e erros; --fonte-2: 1rem para o corpo e os campos; --fonte-3: 1.25rem para subtítulos, legendas e apresentação; --fonte-4: 1.75rem para h2; --fonte-5: clamp(2rem, 5vw, 3.5rem) para h1, ajustando o título à tela dentro desses limites. As entrelinhas são --linha-texto: 1.65 e --linha-titulo: 1.2. ESPAÇAMENTOS: adotei uma escala modular baseada em 0.25rem, equivalente a 4px quando a fonte raiz é 16px. As variáveis --espaco-1 a --espaco-8 correspondem a 0.25rem, 0.5rem, 0.75rem, 1rem, 1.5rem, 2rem, 3rem e 4rem. Todos os valores são múltiplos da unidade base e são aplicados a margens, preenchimentos e gaps, mantendo consistência entre navegação, blocos e formulário. JUSTIFICATIVA: o verde e as superfícies claras estabelecem uma identidade acolhedora para a ONG. A fonte do sistema, os tamanhos relativos em rem e as entrelinhas favorecem a leitura. Os textos escuros contrastam com os fundos claros; o contorno dos campos é mais escuro que as bordas decorativas. O foco de teclado é visível, e os erros têm mensagens textuais além da cor. Essas escolhas apoiam públicos com diferentes necessidades de leitura e navegação, sem depender apenas de sinais visuais coloridos.
```

### CSS 2 — Estrutura do Grid de 12 colunas

```text
Implementei o layout principal no elemento main com display: grid e grid-template-columns: repeat(12, minmax(0, 1fr)). As 12 trilhas têm larguras iguais e podem encolher sem impor a largura mínima do conteúdo. A regra main > * usa grid-column: 1 / -1 e min-width: 0, de modo que os blocos ocupam inicialmente todas as colunas. O contêiner tem width: 100%, margens laterais automáticas e largura máxima limitada. O gap utiliza variáveis da escala de espaçamentos. A estratégia mobile-first começa com blocos empilhados e campos em uma coluna. Cinco media queries com min-width, em 480, 768, 1024, 1280 e 1536 pixels, acrescentam adaptações progressivas. A partir de 1024px, os artigos dos projetos usam grid-column: span 6 e ficam lado a lado. A partir de 1280px, o formulário e sua mensagem de resultado ocupam as linhas 2 / 12, equivalentes a dez colunas; em 1536px, passam para 3 / 11, equivalentes a oito colunas centrais. Os demais blocos continuam com a largura das 12 colunas. Dentro do formulário, um Grid independente organiza os campos em duas colunas a partir de 768px. O cabeçalho e as listas de navegação continuam usando Flexbox. Assim, o Grid controla a distribuição principal e o Flexbox os alinhamentos internos, preservando a ordem semântica do HTML e sem alterar as pastas do projeto.
```

### CSS 3 — Cinco breakpoints e estratégia responsiva

```text
Adotei cinco breakpoints mobile-first com @media (min-width: ...): 480px aumenta o espaçamento entre blocos e o preenchimento lateral; 768px organiza os campos em duas colunas, amplia o espaço vertical e libera a largura do botão; 1024px distribui cada artigo de projeto em seis colunas e coloca o cabeçalho em linha; 1280px amplia o contêiner para 1200px e centraliza o formulário em dez colunas (2 / 12); 1536px limita o contêiner a 1440px e centraliza o formulário em oito colunas (3 / 11), evitando campos excessivamente largos. Abaixo de 480px, os blocos ficam empilhados e o botão ocupa a largura disponível. O Grid principal mantém 12 colunas em todos os cenários; muda a quantidade ocupada pelos componentes. As regras são cumulativas e preservam a ordem de leitura.
```

### CSS 4 — Módulos estruturais com Flexbox

Adicione um módulo por vez. Copie a primeira coluna para “Nome do componente ou contentor” e a segunda para “Propriedades Flexbox aplicadas”. Os textos respeitam os limites de 150 e 500 caracteres.

| Nome do componente ou contentor | Propriedades Flexbox aplicadas |
|---|---|
| Cabeçalho principal (header) | display: flex; flex-wrap: wrap; justify-content: space-between; gap: var(--espaco-4). Abaixo de 1024px, flex-direction: column e align-items: flex-start empilham a identificação da ONG e o menu. A partir de 1024px, flex-direction: row e align-items: center colocam os elementos lado a lado, centralizados no eixo vertical. O espaço livre separa a marca da navegação. |
| Lista de links da navegação principal (nav ul) | display: flex; flex-wrap: wrap; gap: var(--espaco-2). Os links seguem a direção horizontal padrão, mantendo a ordem Início, Projetos sociais, Participe e Cadastro. Quando falta espaço, os itens passam para outra linha. O gap padroniza a distância entre eles sem exigir larguras fixas. |
| Navegação interna da página de projetos (nav com aria-label="Nesta página" > ul) | A lista utiliza a regra compartilhada nav ul: display: flex; flex-wrap: wrap; gap: var(--espaco-2). Os atalhos para projetos, voluntariado e doações ficam lado a lado enquanto houver espaço e quebram em novas linhas em telas menores, preservando a ordem do HTML e a navegação por teclado. |

Os dois menus são componentes distintos que reutilizam a mesma regra CSS. O layout principal de 12 colunas e o agrupamento dos campos do formulário utilizam Grid, por isso não foram listados como exemplos de Flexbox.

---

## Etapa 3 — Componentes visuais e navegação

Esta seção reúne as próximas respostas sobre navegação interativa, cartões, formulários, botões e componentes de feedback.

### Componentes 1 — Menu dropdown e navegação móvel

```text
Implementei a navegação nas quatro páginas com #menu-principal, .menu-toggle, .submenu e .submenu-lista. A lista principal utiliza Flexbox. A abordagem é mobile-first: abaixo de 1024px, #menu-principal > ul usa flex-direction: column. Com JavaScript ativo, o botão “☰ Menu” fica visível e alterna o atributo hidden da navegação; aria-controls identifica o menu controlado e aria-expanded informa seu estado. A regra [hidden] aplica display: none, retirando os links fechados da navegação por teclado. A media query @media (min-width: 1024px) muda a lista para flex-direction: row. O JavaScript acompanha o mesmo breakpoint com matchMedia, oculta o botão e mantém a navegação aberta em telas maiores. Para o dropdown, utilizei details e summary nativos, preservando o link direto “Projetos sociais”. .submenu-lista fica com display: none enquanto o details está fechado; .submenu[open] > .submenu-lista aplica display: flex e flex-direction: column. No desktop, o item pai usa position: relative e a lista suspensa recebe position: absolute, top: 100%, left: 0 e z-index: 10. No celular, ela permanece no fluxo normal, evitando sobreposição. O usuário abre o submenu por clique, Enter ou Espaço; a interação não depende apenas de hover. As pseudo-classes :hover e :focus-visible fornecem destaque e foco de teclado. Escape fecha o submenu e devolve o foco ao summary; outro Escape fecha o menu móvel e devolve o foco ao botão. Clicar fora do cabeçalho ou escolher um link também fecha os componentes. As transições de background-color e color duram 0.18s; @media (prefers-reduced-motion: reduce) remove esses efeitos. Sem JavaScript, os links permanecem disponíveis e o dropdown continua funcionando por meio de details/summary. A ordem Início, Projetos sociais, Participe e Cadastro é preservada.
```

### Componentes 2 — Estados interativos, feedback e validação visual

```text
Apliquei estados visuais aos botões e campos sem depender apenas de cor. Os botões têm transições curtas de background-color, box-shadow e transform. Em :hover, o fundo passa da cor primária para --escuro e surge uma sombra; em :focus-visible, aparece um anel contrastante para navegação por teclado; em :active, há pequeno deslocamento vertical; em :disabled, a opacidade diminui, o cursor muda e a sombra é removida. Inputs e selects mudam a borda no hover e recebem sombra de foco. As pseudo-classes :valid e :invalid sinalizam campos preenchidos corretamente ou com erro, enquanto [aria-invalid="true"] reforça o erro após a validação do JavaScript. O elemento #resultado recebe feedback-erro quando a tentativa é bloqueada e feedback-sucesso quando todos os campos válidos são conferidos. O erro usa fundo rosado, borda vermelha, texto escuro e mensagem textual; o sucesso usa fundo verde-claro, borda verde e mensagem de confirmação. Assim, a informação não depende somente de vermelho ou verde. O formulário mantém required, type, pattern e os limites nativos, e o navegador continua apresentando suas mensagens. As transições duram 0.18s; a regra prefers-reduced-motion: reduce remove-as para pessoas que solicitam menos movimento. Os testes cobrem submissão vazia, classe visual de erro, correção dos dados e classe de sucesso.
```


### Componentes 3 — Capturas para anexar

O formulário de upload aceita imagens individuais. Use estes títulos:

| Título | Arquivo |
|---|---|
| Menu dropdown no desktop | `entrega/captura-menu-dropdown.png` |
| Menu hambúrguer no mobile | `entrega/captura-menu-mobile.png` |
| Formulário com feedback de erro | `entrega/captura-formulario-erro.png` |

As capturas mostram o dropdown aberto em tela ampla, o menu hambúrguer aberto em uma largura móvel e a indicação visual de erro ao tentar validar o formulário vazio. Todas estão abaixo de 50 MB.
